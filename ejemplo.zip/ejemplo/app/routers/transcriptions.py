from fastapi import APIRouter, UploadFile, HTTPException
from app.services.transcription import process_and_store_transcription

router = APIRouter()

@router.post("/transcriptions")
async def transcribe_audio(files: list[UploadFile] = File(...)):
    """
    Procesa múltiples archivos de audio y devuelve las transcripciones.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No se enviaron archivos para procesar.")

    results = []
    for file in files:
        try:
            transcription_data = await process_and_store_transcription(file)
            results.append(transcription_data)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error al procesar el archivo {file.filename}: {str(e)}")

    return {"transcriptions": results}