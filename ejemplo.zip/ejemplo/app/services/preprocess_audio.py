import librosa
import soundfile as sf
import os
from pydub import AudioSegment
from pydub.silence import split_on_silence
import tempfile  # Para manejar archivos temporales

def remove_silence(audio, sample_rate, silence_thresh=-40, min_silence_len=500):
    """
    Elimina los silencios largos del audio.
    
    :param audio: El audio cargado como un array de numpy
    :param sample_rate: La frecuencia de muestreo del audio
    :param silence_thresh: Umbral de decibelios por debajo del cual se considera silencio
    :param min_silence_len: Duración mínima del silencio en ms que se eliminará
    :return: El audio sin silencios
    """
    # Convertir el array de librosa a pydub AudioSegment para procesar
    audio_segment = AudioSegment(
        (audio * 32767).astype("int16").tobytes(),
        frame_rate=sample_rate,
        sample_width=2,
        channels=1
    )

    # Dividir el audio en chunks eliminando los silencios largos
    chunks = split_on_silence(
        audio_segment,
        min_silence_len=min_silence_len,
        silence_thresh=silence_thresh
    )

    # Si hay muchos silencios, concatenar el audio en un solo segmento
    if chunks:
        processed_audio = AudioSegment.silent(duration=0)
        for chunk in chunks:
            processed_audio += chunk

        # Crear un archivo temporal para exportar el audio procesado
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
            temp_path = temp_file.name
            processed_audio.export(temp_path, format="wav")

        # Cargar el archivo temporal de nuevo en librosa
        audio_no_silence, _ = librosa.load(temp_path, sr=sample_rate)

        # Eliminar el archivo temporal
        os.remove(temp_path)

        return audio_no_silence  # Sin normalización de volumen
    else:
        return audio  # Si no hay silencio significativo, retornar el audio original

def preprocess_audio(file, target_sample_rate=16000):
    """
    Carga y preprocesa un archivo de audio recibido como un objeto UploadFile de FastAPI,
    asegurando que tenga la frecuencia de muestreo adecuada.
    """
    # Guardar temporalmente el archivo
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
        temp_path = temp_file.name
        temp_file.write(file.file.read())

    # Cargar el audio desde el archivo temporal
    audio, sample_rate = librosa.load(temp_path, sr=target_sample_rate)

    # Eliminar silencios
    audio_no_silence = remove_silence(audio, sample_rate)

    # Eliminar el archivo temporal
    os.remove(temp_path)

    return audio_no_silence, target_sample_rate

def save_processed_audio(audio, sample_rate, output_path):
    """
    Guarda el archivo de audio procesado en formato WAV.
    """
    sf.write(output_path, audio, sample_rate, format='WAV')
    print(f"Archivo guardado en formato WAV: {output_path}")
